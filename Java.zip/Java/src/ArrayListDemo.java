import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListDemo {
    public static void run() {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Java");
        arrayList.add("Python");
        System.out.println("ArrayList: " + arrayList);

        LinkedList<String> linkedList = new LinkedList<>();
        linkedList.add("C");
        linkedList.add("JavaScript");
        System.out.println("LinkedList: " + linkedList);
    }
}
