import java.util.ArrayList;
import java.util.Collections;

public class ComparatorComparable {
    public static void run() {
        ArrayList<String> list = new ArrayList<>();
        list.add("Banana");
        list.add("Apple");
        list.add("Orange");

        Collections.sort(list);  // Uses Comparable (natural ordering)
        System.out.println("Sorted List: " + list);
    }
}
