public class WrapperClasses {
    public static void run() {
        int num = 10;
        Integer wrappedNum = Integer.valueOf(num); // Wrapping primitive int into Integer object
        System.out.println("Wrapped Integer: " + wrappedNum);

        double pi = 3.14;
        Double wrappedPi = Double.valueOf(pi); // Wrapping primitive double into Double object
        System.out.println("Wrapped Double: " + wrappedPi);
    }
}
