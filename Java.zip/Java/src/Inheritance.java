public class Inheritance {
    public static void run() {
        Dog dog = new Dog();
        dog.speak();
        dog.walk();
    }
}

class Animal {
    void speak() {
        System.out.println("Animal is speaking");
    }
}

class Dog extends Animal {
    void walk() {
        System.out.println("Dog is walking");
    }
}
