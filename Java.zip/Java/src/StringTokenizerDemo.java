public class StringTokenizerDemo{
    public static void run() {
        String sentence = "Java is fun";
        StringTokenizer tokenizer = new StringTokenizer(sentence);

        while (tokenizer.hasMoreTokens()) {
            System.out.println(tokenizer.nextToken());
        }
    }
}
