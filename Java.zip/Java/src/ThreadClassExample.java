class MyThread extends Thread {
    public void run() {
        System.out.println("Thread is running!");
    }
}

public class ThreadClassExample {
    public static void run() {
        MyThread t = new MyThread();
        t.start();
    }
}
