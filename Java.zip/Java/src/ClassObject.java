public class ClassObject {
    public static void run() {
        Car car1 = new Car("Toyota", "Corolla", 2020);
        car1.displayDetails();
    }
}

class Car {
    String make, model;
    int year;

    Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    void displayDetails() {
        System.out.println("Car Make: " + make + ", Model: " + model + ", Year: " + year);
    }
}
