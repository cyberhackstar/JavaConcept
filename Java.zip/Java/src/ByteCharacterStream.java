import java.io.*;

public class ByteCharacterStream{
    public static void run() throws IOException {
        // Byte Stream Example
        FileInputStream byteInputStream = new FileInputStream("bytefile.txt");
        FileOutputStream byteOutputStream = new FileOutputStream("byteoutput.txt");

        int byteData;
        while ((byteData = byteInputStream.read()) != -1) {
            byteOutputStream.write(byteData);
        }
        byteInputStream.close();
        byteOutputStream.close();
        System.out.println("Byte stream copied successfully!");

        // Character Stream Example
        FileReader charReader = new FileReader("charfile.txt");
        FileWriter charWriter = new FileWriter("charoutput.txt");

        int charData;
        while ((charData = charReader.read()) != -1) {
            charWriter.write(charData);
        }
        charReader.close();
        charWriter.close();
        System.out.println("Character stream copied successfully!");
    }
}
