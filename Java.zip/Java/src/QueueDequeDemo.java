import java.util.LinkedList;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Deque;

public class QueueDequeDemo {
    public static void run() {
        Queue<String> queue = new LinkedList<>();
        queue.add("Java");
        queue.add("Python");
        System.out.println("Queue: " + queue.poll());  // Removes and returns the first element

        Deque<String> deque = new ArrayDeque<>();
        deque.addFirst("First");
        deque.addLast("Last");
        System.out.println("Deque: " + deque.removeFirst());  // Removes and returns the first element
    }
}
