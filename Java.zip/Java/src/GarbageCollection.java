class MyObject {
    protected void finalize() {
        System.out.println("Object is being garbage collected.");
    }
}

public class GarbageCollection {
    public static void run() {
        MyObject obj = new MyObject();
        obj = null; // Dereferencing the object, making it eligible for GC
        System.gc(); // Requesting garbage collection
    }
}
