//// In package mypackage/Calculator.java
//package mypackage;
//
//public class Calculator {
//    public int add(int a, int b) {
//        return a + b;
//    }
//}
//
//// In main file
//import mypackage.Calculator;
//
//public class UserDefinedPackages {
//    public static void run() {
//        Calculator calc = new Calculator();
//        System.out.println("Sum: " + calc.add(10, 20));
//    }
//}
