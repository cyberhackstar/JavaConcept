public class CheckedUnchecked{
    public static void run() {
        try {
            // Checked Exception: Compiled time check
            throw new Exception("This is a checked exception.");
        } catch (Exception e) {
            System.out.println("Caught checked exception: " + e.getMessage());
        }

        // Unchecked Exception: No compile-time check
        int[] numbers = new int[2];
        try {
            numbers[3] = 10;  // ArrayIndexOutOfBoundsException (Unchecked)
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught unchecked exception: " + e.getMessage());
        }
    }
}
