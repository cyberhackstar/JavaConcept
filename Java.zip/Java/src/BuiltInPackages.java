import java.util.*;

public class BuiltInPackages {
    public static void run() {
        // Using ArrayList from java.util package
        List<String> fruits = new ArrayList<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");

        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}
