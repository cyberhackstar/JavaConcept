public class AutoboxingUnboxing {
    public static void run() {
        int primitiveInt = 5;
        Integer wrapperInt = primitiveInt; // Autoboxing
        System.out.println("Autoboxing: " + wrapperInt);

        Integer wrapperDouble = 10;
        int unboxedInt = wrapperDouble; // Unboxing
        System.out.println("Unboxing: " + unboxedInt);
    }
}
