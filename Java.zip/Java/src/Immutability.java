public class Immutability {
    public static void run() {
        String str1 = "Java";
        String str2 = str1;
        str1 = "Python";  // str1 now points to a new object
        System.out.println("str1: " + str1);
        System.out.println("str2: " + str2);  // str2 is still pointing to "Java"
    }
}
