public class StackOverflowExample {
    public static void recursiveMethod() {
        recursiveMethod(); // Calling itself infinitely
    }

    public static void run() {
        recursiveMethod(); // This will cause a stack overflow
    }
}
