import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface MyCustomAnnotation {
    String author();
    String date();
}

public class CustomAnnotations {
    @MyCustomAnnotation(author = "John", date = "2023-08-01")
    public void myMethod() {
        System.out.println("This is a method with a custom annotation.");
    }

    public static void run() {
        CustomAnnotations obj = new CustomAnnotations();
        obj.myMethod();
    }
}
