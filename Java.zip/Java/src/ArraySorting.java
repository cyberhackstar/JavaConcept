import java.util.Arrays;

public class ArraySorting {
    public static void run() {
        int[] numbers = {3, 1, 4, 1, 5, 9};
        Arrays.sort(numbers);
        System.out.println("Sorted Array: " + Arrays.toString(numbers));
    }
}
