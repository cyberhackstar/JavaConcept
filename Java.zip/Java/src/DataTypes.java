public class DataTypes {
    public static void run() {
        int age = 25;
        double height = 5.9;
        boolean isStudent = true;
        char grade = 'A';

        System.out.println("Age: " + age + ", Height: " + height + ", Is Student: " + isStudent + ", Grade: " + grade);
    }
}
