public class Polymorphism {
    public static void run() {
        Animal animal = new Animal();
        animal.speak();

        Animal dog = new Dog();
        dog.speak();  // The Dog's speak method is called here
    }
}

class Animal {
    void speak() {
        System.out.println("Animal is speaking");
    }
}

class Dog extends Animal {
    @Override
    void speak() {
        System.out.println("Dog is barking");
    }
}
