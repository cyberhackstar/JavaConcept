//class OuterClass1 {
//    static String outerVar = "Outer class variable";
//
//    static class StaticNestedClass {
//        public void display() {
//            System.out.println(outerVar); // Accessing static outer class variable
//        }
//    }
//
//    public static void run() {
//        OuterClass1.StaticNestedClass nested = new OuterClass1.StaticNestedClass();
//        nested.display();
//    }
//}
