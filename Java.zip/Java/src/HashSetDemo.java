import java.util.HashSet;
import java.util.TreeSet;

public class HashSetDemo {
    public static void run() {
        HashSet<String> hashSet = new HashSet<>();
        hashSet.add("Apple");
        hashSet.add("Banana");
        hashSet.add("Apple");  // Duplicate element is ignored
        System.out.println("HashSet: " + hashSet);

        TreeSet<String> treeSet = new TreeSet<>();
        treeSet.add("Banana");
        treeSet.add("Apple");
        treeSet.add("Orange");
        System.out.println("TreeSet: " + treeSet);
    }
}
