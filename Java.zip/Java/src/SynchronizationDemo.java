class SyncExample {
    synchronized void syncMethod() {
        System.out.println(Thread.currentThread().getName() + " is running...");
    }
}

public class SynchronizationDemo {
    public static void run() {
        SyncExample obj = new SyncExample();
        Thread t1 = new Thread(() -> obj.syncMethod());
        Thread t2 = new Thread(() -> obj.syncMethod());

        t1.start();
        t2.start();
    }
}
