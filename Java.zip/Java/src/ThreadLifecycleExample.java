class LifecycleThread extends Thread {
    public void run() {
        try {
            Thread.sleep(1000); // Simulating some work
            System.out.println("Thread is running!");
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted!");
        }
    }
}

public class ThreadLifecycleExample {
    public static void run() {
        LifecycleThread thread = new LifecycleThread();
        System.out.println("Thread state before start: " + thread.getState());
        thread.start();
        System.out.println("Thread state after start: " + thread.getState());
    }
}
