public class ExceptionHandlingExample {
    public static void run() {
        try {
            int result = 10 / 0;  // This will throw an ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("This block is always executed.");
        }
    }
}
