class Person4 implements Cloneable {
    String name;
    int age;

    Person4(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class CloneDemo {
    public static void run() {
        try {
            Person4 person1 = new Person4("Alice", 30);
            Person4 person2 = (Person4) person1.clone(); // Cloning person1
            System.out.println(person2.name + " " + person2.age);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
    }
}
