class Person3 {
    String name;
    int age;

    Person3(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public int hashCode() {
        return name.hashCode() + age;
    }
}

public class HashCode{
    public static void run() {
        Person3 person31 = new Person3("Alice", 30);
        System.out.println("HashCode: " + person31.hashCode());
    }
}
