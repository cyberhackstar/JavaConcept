public class Operators {
    public static void run() {
        int a = 10, b = 5;

        System.out.println("Arithmetic (a + b): " + (a + b));
        System.out.println("Relational (a > b): " + (a > b));
        System.out.println("Logical (a > 5 && b < 10): " + (a > 5 && b < 10));
        System.out.println("Bitwise (a & b): " + (a & b));
    }
}
