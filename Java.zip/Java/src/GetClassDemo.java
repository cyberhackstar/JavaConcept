class Person {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

public class GetClassDemo {
    public static void run() {
        Person4 person4 = new Person4("Alice", 30);
        System.out.println("Class Name: " + person4.getClass().getName());
    }
}
