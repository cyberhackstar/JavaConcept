public class Arrays1D2D {
    public static void run() {
        int[] arr1D = {1, 2, 3, 4};
        System.out.println("1D Array: " + arr1D[2]);  // Accessing 3rd element

        int[][] arr2D = {{1, 2}, {3, 4}, {5, 6}};
        System.out.println("2D Array: " + arr2D[1][1]);  // Accessing element in 2nd row, 2nd column
    }
}
