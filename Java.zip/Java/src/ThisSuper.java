public class ThisSuper{
    public static void run() {
        Child child = new Child();
        child.displayDetails();
    }
}

class Parent {
    String name = "Parent";

    void showName() {
        System.out.println("Parent name: " + name);
    }
}

class Child extends Parent {
    String name = "Child";

    void displayDetails() {
        System.out.println("Child name: " + this.name);  // 'this' refers to child class
        System.out.println("Parent name: " + super.name);  // 'super' refers to parent class
    }
}
