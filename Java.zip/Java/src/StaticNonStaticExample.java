class MyClass {
    static int staticVar = 10; // Static variable
    int nonStaticVar = 20; // Non-static variable

    static void staticMethod() {
        System.out.println("This is a static method.");
    }

    void nonStaticMethod() {
        System.out.println("This is a non-static method.");
    }
}

public class StaticNonStaticExample {
    public static void run() {
        MyClass.staticMethod(); // Accessing static method without creating an instance
        MyClass obj = new MyClass();
        obj.nonStaticMethod(); // Accessing non-static method after creating an instance
    }
}
