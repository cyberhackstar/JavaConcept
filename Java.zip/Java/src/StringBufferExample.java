public class StringBufferExample {
    public static void run() {
        StringBuffer sb = new StringBuffer("Hello");
        sb.append(" World!");
        System.out.println(sb);  // Outputs "Hello World!"
    }
}
