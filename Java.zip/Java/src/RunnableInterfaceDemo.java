class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Runnable is running!");
    }
}

public class RunnableInterfaceDemo {
    public static void run() {
        MyRunnable task = new MyRunnable();
        Thread t = new Thread(task);
        t.start();
    }
}
