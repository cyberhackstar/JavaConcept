public class StringPool {
    public static void run() {
        String str1 = "Java";
        String str2 = "Java";
        System.out.println(str1 == str2);  // true, both point to the same string pool object
    }
}
