public class StackVsHeap {
    public static void run() {
        int stackVar = 10; // Stack memory

        String heapVar = new String("Hello from Heap!"); // Heap memory
        System.out.println("Stack variable: " + stackVar);
        System.out.println("Heap variable: " + heapVar);
    }
}
