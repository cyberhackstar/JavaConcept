//interface Greeting {
//    void sayHello();
//}
//
//public class AnonymousInnerClassExample {
//    public static void run() {
//        Greeting greeting = new Greeting() {
//            public void sayHello() {
//                System.out.println("Hello from Anonymous Inner Class!");
//            }
//        };
//        greeting.sayHello();
//    }
//}
