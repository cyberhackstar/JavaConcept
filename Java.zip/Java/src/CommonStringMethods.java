public class CommonStringMethods {
    public static void run() {
        String str = "Hello";
        System.out.println("Length: " + str.length());
        System.out.println("Character at position 1: " + str.charAt(1));

        StringBuilder sb = new StringBuilder("World");
        sb.append("!");
        System.out.println("Appended String: " + sb.toString());
    }
}
