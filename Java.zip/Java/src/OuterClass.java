class OuterClass {
    private String outerVar = "Outer class variable";

    class InnerClass {
        public void display() {
            System.out.println(outerVar); // Accessing outer class variable
        }
    }

    public static void run() {
        OuterClass1 outer = new OuterClass1();
        OuterClass1.InnerClass inner = outer.new InnerClass();
        inner.display();
    }
}
