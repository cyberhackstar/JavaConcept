public class JvmJreJdk {
    public static void run() {
        System.out.println("=== JVM, JRE, JDK ===");
        System.out.println("JDK = JRE + Development Tools");
        System.out.println("JRE = JVM + Libraries");
        System.out.println("JVM runs Java bytecode on any platform");
    }
}
