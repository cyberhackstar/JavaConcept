import java.util.ArrayList;

public class MemoryLeaks {
    public static void run() {
        ArrayList<Object> list = new ArrayList<>();
        for (int i = 0; i < 1000000; i++) {
            list.add(new Object()); // Retaining memory unnecessarily
        }
        System.out.println("Memory leak is simulated.");
    }
}
