public class AbstractionInterface {
    public static void run() {
        Shape circle = new Circle();
        circle.draw();  // Calls abstract method
    }
}

abstract class Shape {
    abstract void draw();  // Abstract method
}

class Circle extends Shape {
    void draw() {
        System.out.println("Drawing a Circle");
    }
}
