//class OuterClass {
//    void display() {
//        class LocalInnerClass {
//            public void printMessage() {
//                System.out.println("Inside Local Inner Class");
//            }
//        }
//        LocalInnerClass inner = new LocalInnerClass();
//        inner.printMessage();
//    }
//
//    public static void run() {
//        OuterClass outer = new OuterClass();
//        outer.display();
//    }
//}
