public class HistoryAndFeatures {
    public static void run() {
        System.out.println("=== Java History and Features ===");
        Student student = new Student("Aman", 21);
        student.display();
    }
}

class Student {
    String name;
    int age;

    Student(String name, int age) { // Constructor initializes values
        this.name = name;
        this.age = age;
    }

    void display() { // Method to print student data
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
