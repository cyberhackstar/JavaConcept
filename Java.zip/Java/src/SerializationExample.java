import java.io.*;

class Student1 implements Serializable {
    String name;
    int age;

    public Student1(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

public class SerializationExample {
    public static void run() throws IOException, ClassNotFoundException {
        Student1 student1 = new Student1("Alice", 22);
        FileOutputStream fileOut = new FileOutputStream("student.ser");
        ObjectOutputStream out = new ObjectOutputStream(fileOut);
        out.writeObject(student1);
        out.close();
        fileOut.close();

        FileInputStream fileIn = new FileInputStream("student.ser");
        ObjectInputStream in = new ObjectInputStream(fileIn);
        Student1 deserializedStudent1 = (Student1) in.readObject();
        in.close();
        fileIn.close();

        System.out.println("Deserialized Student: " + deserializedStudent1.name + ", " + deserializedStudent1.age);
    }
}
