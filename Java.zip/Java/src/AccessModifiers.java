public class AccessModifiers {
    public String publicVar = "Accessible to all";
    private String privateVar = "Accessible only within the class";
    protected String protectedVar = "Accessible within the package and subclasses";
    String defaultVar = "Accessible within the package";

    public static void run() {
        AccessModifiers obj = new AccessModifiers();
        System.out.println(obj.publicVar);
        System.out.println(obj.privateVar); // Error: Not accessible outside class
    }
}
