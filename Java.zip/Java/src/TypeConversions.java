public class TypeConversions {
    public static void run() {
        double pi = 3.14159;
        int piInt = (int) pi; // Casting double to int
        System.out.println("Double to Int: " + piInt);

        String numberString = "123";
        int number = Integer.parseInt(numberString); // Parsing string to int
        System.out.println("String to Int: " + number);
    }
}
