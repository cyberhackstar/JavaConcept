class Person2 {
    String name;
    int age;

    Person2(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Person2 person2 = (Person2) obj;
        return age == person2.age && name.equals(person2.name);
    }
}

public class EqualsExample {
    public static void run() {
        Person2 person21 = new Person2("Alice", 30);
        Person2 person2 = new Person2("Alice", 30);
        System.out.println(person21.equals(person2)); // true
    }
}
