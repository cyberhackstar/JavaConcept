public class ArrayTraversal {
    public static void run() {
        int[] numbers = {10, 20, 30, 40};
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }
    }
}
