public class ConstructorExample {
    public static void run() {
        Car car1 = new Car("Honda", "Civic", 2022);
        car1.displayDetails();
    }
}

class Car {
    String make, model;
    int year;

    // Constructor to initialize the object
    Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    void displayDetails() {
        System.out.println("Car Make: " + make + ", Model: " + model + ", Year: " + year);
    }
}
