class BuiltInAnnotations{
    @Override
    public String toString() {
        return "MyClass object";
    }

    @Deprecated
    public void oldMethod() {
        System.out.println("This method is deprecated");
    }

    public static void run() {
        BuiltInAnnotations obj = new BuiltInAnnotations();
        System.out.println(obj.toString());
        obj.oldMethod();
    }
}
