public class Encapsulation {
    public static void run() {
        Person1 person1 = new Person1();
        person1.setName("John");
        person1.setAge(25);
        System.out.println("Name: " + person1.getName() + ", Age: " + person1.getAge());
    }
}

class Person {
    private String name;
    private int age;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }
}
