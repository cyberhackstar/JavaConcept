enum Day {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
}

public class EnumBasics {
    public static void run() {
        Day today = Day.MONDAY;
        System.out.println("Today is: " + today);
    }
}
