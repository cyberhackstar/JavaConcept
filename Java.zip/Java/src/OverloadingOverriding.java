public class OverloadingOverriding {
    public static void run() {
        System.out.println("Addition of 2 numbers: " + add(2, 3));
        System.out.println("Addition of 3 numbers: " + add(2, 3, 4));

        Animal1 animal = new Animal1();
        animal.speak();

        Dog1 dog = new Dog1();
        dog.speak();  // Dog overrides speak method
    }

    // Method overloading
    static int add(int a, int b) {
        return a + b;
    }

    static int add(int a, int b, int c) {
        return a + b + c;
    }
}

class Animal1 {
    void speak() {
        System.out.println("Animal is speaking");
    }
}

class Dog1 extends Animal1 {
    @Override
    void speak() {
        System.out.println("Dog is barking");
    }
}
