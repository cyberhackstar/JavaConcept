class WaitNotifyExample {
    synchronized void printNumbers() {
        try {
            for (int i = 1; i <= 5; i++) {
                System.out.println(i);
                wait();
            }
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    synchronized void notifyThread() {
        notify();
    }
}

public class WaitNotify {
    public static void run() throws InterruptedException {
        WaitNotifyExample obj = new WaitNotifyExample();
        Thread t1 = new Thread(() -> obj.printNumbers());
        Thread t2 = new Thread(() -> obj.notifyThread());

        t1.start();
        Thread.sleep(1000);  // Adding delay to ensure t1 waits
        t2.start();
    }
}
