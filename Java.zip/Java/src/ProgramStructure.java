public class ProgramStructure {
    public static void run() {
        System.out.println("=== Java Program Structure ===");
        Message.print("Java is structured and readable.");
    }
}

class Message {
    static void print(String msg) {
        System.out.println(msg);
    }
}
