class Resource {
    public void finalize() {
        System.out.println("Releasing resources before object is destroyed.");
    }
}

public class FinalizeDemo {
    public static void run() {
        Resource res = new Resource();
        res = null; // Make object eligible for garbage collection
        System.gc(); // Request garbage collection
    }
}
