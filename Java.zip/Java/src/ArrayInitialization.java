public class ArrayInitialization {
    public static void run() {
        // Static initialization
        int[] staticArray = {1, 2, 3};
        System.out.println("First element: " + staticArray[0]);

        // Dynamic initialization
        int[] dynamicArray = new int[3];
        dynamicArray[0] = 5;
        dynamicArray[1] = 10;
        dynamicArray[2] = 15;
        System.out.println("First element: " + dynamicArray[0]);
    }
}
