public class StringExample {
    public static void run() {
        String message = "Hello, World!";
        System.out.println(message);

        // String operations
        String greeting = "Hello";
        String name = "Alice";
        String fullGreeting = greeting + " " + name;
        System.out.println(fullGreeting);
    }
}
