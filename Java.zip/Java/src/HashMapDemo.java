import java.util.HashMap;
import java.util.TreeMap;

public class HashMapDemo {
    public static void run() {
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Alice", 25);
        hashMap.put("Bob", 30);
        System.out.println("HashMap: " + hashMap);

        TreeMap<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Alice", 25);
        treeMap.put("Bob", 30);
        treeMap.put("Charlie", 35);
        System.out.println("TreeMap: " + treeMap);
    }
}
