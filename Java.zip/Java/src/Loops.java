public class Loops {
    public static void run() {
        System.out.println("For Loop:");
        for (int i = 1; i <= 3; i++) {
            System.out.println(i);
        }

        System.out.println("While Loop:");
        int i = 1;
        while (i <= 3) {
            System.out.println(i);
            i++;
        }

        System.out.println("Do-While Loop:");
        i = 1;
        do {
            System.out.println(i);
            i++;
        } while (i <= 3);
    }
}
