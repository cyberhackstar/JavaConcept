public class Variables {
    public static void run() {
        int number = 10;
        double price = 15.99;
        String itemName = "Apple";

        System.out.println("Item: " + itemName + ", Price: $" + price + ", Quantity: " + number);
    }
}
