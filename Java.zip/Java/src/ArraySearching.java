import java.util.Arrays;

public class ArraySearching {
    public static void run() {
        int[] numbers = {3, 1, 4, 1, 5, 9};
        int index = Arrays.binarySearch(numbers, 4);
        System.out.println("Element found at index: " + index);
    }
}
