public class BreakContinue {
    public static void run() {
        System.out.println("Using break:");
        for (int i = 1; i <= 5; i++) {
            if (i == 3) break; // Stops the loop when i is 3
            System.out.println(i);
        }

        System.out.println("Using continue:");
        for (int i = 1; i <= 5; i++) {
            if (i == 3) continue; // Skips printing 3
            System.out.println(i);
        }
    }
}
