public class TypeCasting {
    public static void run() {
        double price = 9.99;
        int roundedPrice = (int) price; // Explicit type casting

        System.out.println("Original price: " + price + ", Rounded price: " + roundedPrice);
    }
}
