public class StringBuilderExample {
    public static void run() {
        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" World!");
        System.out.println(sb);  // Outputs "Hello World!"
    }
}
