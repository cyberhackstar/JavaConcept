class Person1 {
    String name;
    int age;

    Person1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person[name=" + name + ", age=" + age + "]";
    }
}

public class ToStringExample {
    public static void run() {
        Person1 person1 = new Person1("Alice", 30);
        System.out.println(person1.toString());
    }
}
