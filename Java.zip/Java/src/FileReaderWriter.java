import java.io.*;

public class FileReaderWriter{
    public static void run() throws IOException {
        FileWriter writer = new FileWriter("example.txt");
        writer.write("Hello, World!");
        writer.close();

        FileReader reader = new FileReader("example.txt");
        int data;
        while ((data = reader.read()) != -1) {
            System.out.print((char) data);
        }
        reader.close();
    }
}
